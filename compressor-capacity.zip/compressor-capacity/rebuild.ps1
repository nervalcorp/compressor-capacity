<#
    Rebuild the dataset and page from an updated spreadsheet, then stage the
    result at the repo root.

        .\rebuild.ps1 -Source "C:\path\to\workbook.xlsx"

    Add -Push to commit and push in the same run.

    Needs Python 3 with openpyxl:  pip install openpyxl
#>

param(
    [Parameter(Mandatory = $true)][string]$Source,
    [switch]$Push
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $Source)) {
    Write-Host "Spreadsheet not found: $Source" -ForegroundColor Red
    exit 1
}

$py = if (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { "python" }

Write-Host "Extracting..." -ForegroundColor Cyan
& $py scripts\extract.py --source "$Source" --out build
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "Building page..." -ForegroundColor Cyan
& $py scripts\build_page.py --data build\data.json --out index.html
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "Staging outputs at repo root..." -ForegroundColor Cyan
Copy-Item build\data.json .\data.json -Force
if (Test-Path .\csv) { Remove-Item .\csv -Recurse -Force }
Copy-Item build\csv .\csv -Recurse -Force

Write-Host "Rebuilt from $(Split-Path $Source -Leaf)" -ForegroundColor Green

if ($Push) {
    git add -A
    git commit -m "Rebuild from $(Split-Path $Source -Leaf)"
    git push
    Write-Host "Pushed." -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "Review, then commit:" -ForegroundColor Yellow
    Write-Host '  git add -A; git commit -m "Rebuild"; git push'
}
