# Verification log

Tracks which parts of the dataset have been checked against manufacturer data
and which are still raw transcription from the workbook. Update this as
verification progresses so it is always clear what can be trusted.

**Overall status: PROVISIONAL.** Nothing below is confirmed yet.

## Legend

| Mark | Meaning |
|---|---|
| ✅ | checked against manufacturer data and confirmed |
| ⚠️ | discrepancy found — see notes, awaiting John's decision |
| ⬜ | not yet checked |

## Models

Transcription from the workbook is verified for all 15 sheets — 9,450 rendered
cells matched the source with zero mismatches. That is a *fidelity* check
only: it proves the page matches the workbook, not that the workbook matches
the manufacturer.

| Compressor | ICC model(s) | Application | Manufacturer check |
|---|---|---|---|
| SC10CL | SUIC386 | Medium temp | ⬜ |
| NEU6215GK | SUIC500, SUOC500 | Medium temp | ⬜ |
| SC15MLX | SUIC530 | Medium temp | ⬜ |
| NT6222GK | SUIC700, SUOC700 | Medium temp | ⬜ |
| NT6226GK | SUIC1000, SUOC1000, MBIC1000 | Medium temp | ⬜ |
| NJ9238GK | SUIC1500, SUOC1500, MBIC1500 | Medium temp | ⬜ |
| YM34E3G | SUOC2000 | Medium temp | ⬜ |
| YM49E3G | SUOC3000 | Medium temp | ⬜ |
| YM70E3G | SUOC4000 | Medium temp | ⬜ |
| SC10CLX | MBIC350 | Medium temp | ⬜ |
| SC18MLX | MBIC750 | Medium temp | ⬜ |
| NJ2212GJ | MBIF450 | Low temp | ⬜ |
| YF13E3G | MBIF600 | Low temp | ⬜ |
| YF20E3G | MBIF1000 | Low temp | ⬜ |
| YF29E3G | MBIF1500 | Low temp | ⬜ |

## Corrections applied

| Cell | Was | Now | Basis | Confirmed by John |
|---|---|---|---|---|
| `YF13E3G!D9` (R404A, 5 °F suction, 80 °F condensing, Watts) | `a` | 3805 | R507 co-rated block gives 3805 W at the same condition; 12,983 BTU/H × 0.29307 = 3,805 W | ✅ 2026-08-20 |

## Open questions

Things noticed during extraction that are worth resolving during verification.
None of these are errors as such — they may be exactly as intended.

1. **Low-temp models carry medium-temp suction rows.** The MBIF sheets
   (NJ2212GJ, YF13E3G, YF20E3G, YF29E3G) list suction temperatures from 30 °F
   down to −10 °F, the same grid as the medium-temp sheets, rather than an LBP
   range. NJ2212GJ marks 30 through 15 °F as `-` (not rated); the YF sheets
   carry numbers across the whole range. Worth confirming those YF rows are
   real ratings and not a fill-down.

2. **R507 blocks are identical to R404A on every sheet.** Consistent with
   co-rating, and the labels say so on several sheets, but confirm this is
   intended rather than a copy of the block.

3. **Fill colour and label text disagree in places.** On NJ2212GJ the R449A
   and R448A blocks are labelled "NOT approved for LBP — reference only" but
   carry the blue "released" fill. On the YM sheets the R452A block is labelled
   plainly but carries the peach "caution" fill. The page shows both; the
   labels should win, but the fills are worth correcting in the workbook so the
   two agree.

4. **R449A and R448A blocks are identical to each other** wherever both appear,
   and on several sheets identical to R452A. Some of these are explicitly noted
   as proxies or estimates in the labels. Confirm which are genuine published
   data and which are placeholders, since the Δ vs R404A view will otherwise
   show them as real differences.

## History

| Date | Change |
|---|---|
| 2026-08-20 | Initial extraction from `_CLEAN__Condensing_Units_and_Evaps_-_Keeprite_for_comparison.xlsx`. 15 models, 5 refrigerants each, 4,725 rated points, 2,020 not-rated cells. One transcription error found and corrected. Page built and fidelity-checked at 9,450 cells. |
