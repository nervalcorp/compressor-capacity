# compressor-capacity

> **PROVISIONAL — DATA NOT CONFIRMED.**
> Every capacity value in this repository is transcribed from a working
> spreadsheet and is still being checked against manufacturer data. Do not
> quote these figures in quotations, submittals, brochures or spec sheets, and
> do not treat them as published ratings. See
> [`verification-log.md`](verification-log.md) for what has and has not been
> checked.

**Live: https://nervalcorp.github.io/compressor-capacity/**

Rated cooling capacity for condensing units and their InvoTech
compressor equivalents — 15 compressor models, 5 refrigerants each (R404A,
R507, R452A, R449A, R448A), 7 condensing temperatures × 9 suction
temperatures. 4,725 rated points.

This is a temporary staging repository for verification work. It is
intentionally **not** connected to ICC Energy or iCoola — no shared branding,
no shared assets, no cross-imports. That comes later, if and when the data is
signed off.

## Contents

| Path | What it is |
|---|---|
| `index.html` | The capacity tables page. Self-contained — data embedded, no dependencies, no external requests. |
| `data.json` | The dataset, structured. |
| `csv/<MODEL>.csv` | One CSV per compressor model, laid out like the source spreadsheet sheet. |
| `csv/_all-capacities-long.csv` | Every rated point as one flat row, 4,725 rows. Best for pivot tables or Power Query. |
| `extra-sheets/*.json` | Sheets staged as JSON because the .xlsx with that tab is not to hand. Merged at extraction, rendered like any other model. |
| `scripts/extract.py` | Spreadsheet → `data.json` + CSVs. |
| `scripts/build_page.py` | `data.json` → `index.html`. |
| `scripts/build_workbook.py` | `data.json` → `.xlsx`, in the original workbook's format. |
| `Condensing_Units_by_Unit.xlsx` | 30 sheets, one per ICC unit, each with only its selected refrigerants. |
| `Condensing_Units_by_Compressor.xlsx` | 17 sheets, one per compressor, all five refrigerants — the cross-check reference. |
| `verification-log.md` | Per-model checklist, applied corrections, open questions. |

## Two views

**Units** (default) — 30 ICC units grouped by family (SUIC, SUOC, MBIC, SUIF,
SUOF, MBIF), each showing only the refrigerant(s) it is offered with. One
compressor can serve several units with different selections, so the unit is
the entity here, not the compressor.

**Compressors** — the original 17 pages, all five refrigerants side by side,
for cross-checking. Toggle at the left of the toolbar.

Hash links work for both: `#MBIC500` opens the unit, `#NT6226GK` the
compressor. Δ vs R404A still resolves its baseline from the compressor's full
block set, so a unit showing only R448A still gets correct percentages.

Selections live in `SELECTIONS` in `scripts/extract.py`. Several point at
blocks the workbook flags as not released or not suitable; those flags are
shown as-is and are listed in `verification-log.md` pending confirmation.

## Live page

**https://nervalcorp.github.io/compressor-capacity/**

`index.html` also works straight off disk — no server needed.

Because the site is served from GitHub Pages the provisional numbers are
reachable by anyone with the link. That is the reason the PROVISIONAL banner is
on by default and stays on until the data is signed off.

## Rebuilding after the spreadsheet changes

Needs Python 3 and `openpyxl` (`pip install openpyxl`).

```powershell
python scripts\extract.py --source "path\to\workbook.xlsx" --out build
python scripts\build_page.py --data build\data.json --out index.html
copy build\data.json data.json
xcopy /E /Y build\csv csv\
```

The `--release` flag on `build_page.py` removes the PROVISIONAL banner. Do not
use it until the data is confirmed.

## Fixing a wrong value

Do not edit `data.json`, the CSVs, or `index.html` directly — the next
extraction silently reverts the change and nobody can tell which values were
touched.

Instead add the cell to the `CORRECTIONS` map at the top of
`scripts/extract.py`, keyed by sheet and cell, with the corrected value and a
short reason naming the evidence:

```python
CORRECTIONS = {
    ("YF13E3G", "D9"): (
        3805,
        "Source cell held the letter 'a'. The R507 co-rated block on the same "
        "sheet gives 3805 W at this condition, and 12,983 BTU/H x 0.29307 = 3,805 W.",
    ),
}
```

Re-run both scripts. The corrected cell gets a dotted underline on the page
and the reason appears above the table, so a fix is never invisible. Once the
cell is fixed in the spreadsheet itself, delete the entry and re-extract.

## Embedding in an iframe

The page reads its own query string, so one deployed file can serve several
different embeds without maintaining separate copies.

| Parameter | Effect |
|---|---|
| `?hide=` | Hide named parts or raw class names, comma separated |
| `?show=` | The inverse — keep only these named parts, hide the other named ones |
| `?embed=1` | Preset: no masthead, rail or footer, padding collapsed |
| `?bare=1` | Also strip block borders, radius and shadow |
| `?model=` | Open a model — accepts `NT6226GK` or `SUIC1000` |
| `?ref=` | Show only these refrigerant blocks, e.g. `R404A,R452A` |
| `?unit=` | `btu`, `w`, or `both` |
| `?mode=` | `value` or `delta` |
| `?shade=` | `0` or `1` |
| `?height=1` | Post the page height to the parent frame |

Named parts for `hide` / `show`: `masthead`, `provisional`, `toolbar`, `rail`,
`view`, `search`, `units`, `values`, `shading`, `csv`, `print`, `readout`,
`header`, `facts`, `notes`, `legend`, `footer`, `blockhead`.

The Units/Compressors toggle also carries the class `view-uc`, so it can be
targeted directly from your own CSS or with `?hide=view-uc`.

Any other token is read as a class name, so `?hide=ref-icc` works, as does
`?hide=.ref-icc` or `?hide=#foot`. Tokens that are not valid selectors are
ignored rather than injected. Hiding uses injected CSS, so it survives the
re-render that happens when you switch models.

```html
<!-- one model, one refrigerant, chrome stripped -->
<iframe src="https://nervalcorp.github.io/compressor-capacity/?embed=1&bare=1&model=SUIC530&ref=R404A"
        style="width:100%;height:900px;border:0"></iframe>
```

### Auto-sizing the iframe

Add `&height=1` and the page posts its height to the parent:

```html
<iframe id="cap" src="https://nervalcorp.github.io/compressor-capacity/?embed=1&height=1"
        style="width:100%;border:0;height:400px"></iframe>
<script>
window.addEventListener("message", function (e) {
  if (e.data && e.data.type === "capacity-tables:height") {
    document.getElementById("cap").style.height = e.data.height + "px";
  }
});
</script>
```

`?ref=` narrows which blocks are drawn but never changes what Δ vs R404A is
measured against — the baseline is always taken from the full set, so a
single-refrigerant embed still shows correct percentages.

**`?hide=provisional` removes the warning banner.** That is fine for an
internal page where everyone already knows the data is being checked. On
anything a customer or contractor might see, leave the banner on — the numbers
look just as authoritative without it.

## Adding an ICC model number to a sheet

Same principle as a correction — do not edit `data.json`. Add the pairing to
`ICC_MODEL_ADDITIONS` at the top of `scripts/extract.py`:

```python
ICC_MODEL_ADDITIONS = {
    "NEU6215GK": ["MBIC500"],
    "YF13E3G": ["SUIF2000", "SUOF2000"],
    "YF20E3G": ["SUIF1000", "SUOF1000"],
    "YF29E3G": ["SUIF1500", "SUOF1500"],
}
```

It is applied to every block on that sheet, flows into the JSON and CSVs, and
the page shows a note saying the pairing is not in the workbook. The model also
becomes searchable and usable in `?model=`. Remove the entry once the workbook
carries the number itself.

## Staging a sheet the .xlsx does not carry yet

Drop a JSON file in `extra-sheets/`. It is merged at extraction, gets its own
CSV, and renders like any other model.

Set `"sourceType"` to `"workbook"` for a tab that exists in the spreadsheet and
is only staged here for convenience. Any other value marks the model
**Unverified** in the rail and puts a red "Not read from the workbook" panel
above its tables — use that only for data whose origin really is something
other than the workbook.

```jsonc
{
  "name": "YSF60E7G",              // compressor model, becomes the sheet name
  "iccModel": "SUOF3000",
  "sourceType": "workbook",         // anything else flags it as unverified
  "stagedFrom": "why it is here and not in the .xlsx",
  "notes": ["anything that needs checking"],
  "condensing": ["80 (26.7)", "…"], // 7 labels
  "suction": ["30 (-1.1)", "…"],    // 9 labels
  "blocks": [
    { "label": "R404A (rated)", "status": "standard",
      "rows": [[btu, w, btu, w, …]] }   // 9 rows x 14 values
  ]
}
```

`status` is `standard`, `caution` or `note`, matching the workbook's header
fill colours. Delete the file once the tab exists in the workbook and
re-extract — the pipeline is the source of truth, this is a staging area.

## Rebuilding the workbook

```powershell
python scripts\build_workbook.py --data data.json --out Condensing_Units_by_Compressor.xlsx
python scripts\build_workbook.py --data data.json --units --out Condensing_Units_by_Unit.xlsx
```

`--units` writes one sheet per ICC unit with only its selected refrigerants;
without it, one sheet per compressor with all five.

Writes one sheet per compressor model, five refrigerant blocks each at rows
1, 14, 27, 40 and 53 — the source workbook's layout, fonts, fills, borders,
merges and number formats. Corrections, added ICC model numbers and pinned
notes ride along as cell comments on each block header, so the file explains
itself without any change to the grid.

Verified by round-trip: re-extracting the generated file reproduces
`data.json` exactly, 10,710 value cells with zero differences.

Three deliberate departures from the original:

- **Column widths are uniform and wider** (A 31, B 20, data 10). The original
  used narrower per-sheet widths, which is what produced the `#####` overflow
  on the SUOF4000 tab — a number too wide for its column is unreadable in the
  file and in any screenshot of it.
- **Print setup is landscape, fit to one page wide.** All five blocks land on
  one page instead of being sliced down the middle.
- **Stray fills are not carried over.** On SC15MLX and SC18MLX the peach block
  fill had bled onto three data rows in blocks 4 and 5; the rebuild fills only
  the header rows.

The yellow model-cell marker is preserved — `extract.py` reads it off the
source and `build_workbook.py` writes it back, so the sheets you were working
through stay flagged.

## Pinning a note to a model

For anything that needs revisiting — a pairing that looks wrong, a figure taken
on trust, a question for the manufacturer — add it to `SHEET_NOTES` in
`scripts/extract.py`:

```python
SHEET_NOTES = {
    "YF13E3G": [
        "SUIF2000 and SUOF2000 are recorded from the ERP as-is. ...",
    ],
}
```

It appears above that model's tables under a "To review" tag, and in
`data.json` as the sheet's `notes`. The point is that a number recorded on
trust stays visibly on trust until someone checks it, instead of quietly
becoming fact. `verification-log.md` keeps the running list.

## Printing

The print stylesheet defaults the page to **landscape** and sizes the table to
whatever page width is available, so all seven condensing temperatures print
whether the viewer keeps landscape or forces portrait on Letter or A4. Block
fills are preserved with `print-color-adjust: exact` because they carry the
release status. Controls, rail and readout are stripped; blocks never split
across a page.

Print or save-as-PDF from the browser's own dialog — the Print button just
opens it.

## Page features

Model index grouped by application and searchable · per-model hash links
(`index.html#NT6226GK`) · BTU/H, Watts or both · Δ vs R404A · capacity shading
· hover crosshair with readout · per-model CSV download · print stylesheet.

Typography is Arial only, with Courier New for cell references. No web fonts
and no external requests of any kind.
