#!/usr/bin/env python3
"""
Extract the Keeprite / InvoTech comparison workbook into structured JSON + CSV.

Workbook shape (identical on every sheet):
  5 blocks starting at rows 1, 14, 27, 40, 53
  block row+0 : A = ICC model(s), B:P merged = refrigerant label
  block row+1 : A = 'Compressor Model', B = 'Sat. Suction Temp F', C..P = 7 condensing temps (2 cols each)
  block row+2 : B = 'F (C)', C..P = BTU/H | Watts pairs
  block row+3..+11 : 9 suction-temperature data rows
"""
import argparse
import csv
import glob
import json
import os
import re

import openpyxl

NOT_RATED = "-"          # source marker for "outside the rating envelope"

# Known transcription errors in the source workbook, corrected on extraction.
# Keyed by (sheet, cell) -> (corrected value, reason).
CORRECTIONS = {
    ("YF13E3G", "D9"): (
        3805,
        "Source cell held the letter 'a'. The R507 co-rated block on the same "
        "sheet gives 3805 W at this condition, and 12,983 BTU/H x 0.29307 = 3,805 W.",
    ),
}

# ICC model numbers that belong to a sheet but are not in the workbook's model
# column yet. Applied to every block on that sheet. Remove an entry once the
# workbook itself carries the number.
ICC_MODEL_ADDITIONS = {
    "YF20E3G": ["SUIF1000", "SUOF1000"],
    "YF29E3G": ["SUIF1500", "SUOF1500"],
}

ISSUES = []              # cells that are neither a number nor "-"
FIXED = []               # corrections actually applied
ADDED = []               # ICC model numbers added from ICC_MODEL_ADDITIONS

DEFAULT_GLOB = "/mnt/user-data/uploads/*.xlsx"
BLOCK_ROWS = [1, 14, 27, 40, 53]
DATA_ROWS = 9
COND_COLS = list(range(3, 17, 2))  # C, E, G, I, K, M, O

# Excel fill -> semantic status (preserved from the source workbook)
FILL_STATUS = {
    "FFD9E1F2": "standard",  # blue  - rated / released
    "FFFCE4D6": "caution",   # peach - not released / reference only
    "FFFFF2CC": "note",      # yellow- released with a qualifier
}


def split_temp(text):
    """'80 (26.7)' -> (80.0, 26.7). '30 (-1.1)' -> (30.0, -1.1)."""
    m = re.match(r"^\s*(-?[\d.]+)\s*\(\s*(-?[\d.]+)\s*\)\s*$", str(text))
    if not m:
        return None, None
    return float(m.group(1)), float(m.group(2))


def parse_label(label):
    """'R452A (released)' -> ('R452A', 'released')."""
    m = re.match(r"^\s*([^\s(]+)\s*(?:\((.*)\))?\s*$", str(label))
    if not m:
        return str(label), ""
    return m.group(1), (m.group(2) or "").strip()


def num(ws, row, col, ctx):
    """Return (value, flag). value is a number or None ('-' = not rated).
    flag is None, or the raw text of a cell that could not be resolved."""
    coord = ws.cell(row, col).coordinate
    v = ws.cell(row, col).value

    fix = CORRECTIONS.get((ws.title, coord))
    if fix is not None:
        value, reason = fix
        FIXED.append(dict(ctx, cell=coord, raw=str(v).strip(),
                          corrected=value, reason=reason))
        return value, None

    if isinstance(v, (int, float)):
        return v, None
    t = str(v).strip()
    if t == NOT_RATED:
        return None, None
    ISSUES.append(dict(ctx, cell=coord, raw=t))
    return None, t


def cell_fill(ws, row, col):
    c = ws.cell(row, col)
    rgb = None
    if c.fill is not None and c.fill.fgColor is not None:
        rgb = c.fill.fgColor.rgb
    return rgb if isinstance(rgb, str) else None


def find_source():
    hits = sorted(glob.glob(DEFAULT_GLOB))
    if not hits:
        raise SystemExit(
            "No .xlsx found in /mnt/user-data/uploads. Pass the workbook path with --source.")
    if len(hits) > 1:
        raise SystemExit("Several workbooks found; name one with --source:\n  " +
                         "\n  ".join(hits))
    return hits[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", help="path to the capacity workbook (.xlsx)")
    ap.add_argument("--out", default="build", help="output directory (default: build)")
    args = ap.parse_args()

    SRC = args.source or find_source()
    OUT = args.out
    print(f"source: {SRC}")

    os.makedirs(OUT, exist_ok=True)
    os.makedirs(os.path.join(OUT, "csv"), exist_ok=True)

    wb_v = openpyxl.load_workbook(SRC, data_only=True)   # values
    wb_s = openpyxl.load_workbook(SRC)                    # styles

    sheets = []
    long_rows = []

    for ws in wb_v.worksheets:
        ss = wb_s[ws.title]

        # condensing temperatures come from the first block header; verified identical
        # across every block and every sheet.
        cond = []
        for col in COND_COLS:
            raw = ws.cell(2, col).value
            f, c = split_temp(raw)
            cond.append({"label": raw, "f": f, "c": c})

        blocks = []
        icc_models_all = []

        for br in BLOCK_ROWS:
            icc_raw = str(ws.cell(br, 1).value or "").strip()
            icc_models = [m.strip() for m in icc_raw.split(",") if m.strip()]

            extra = [m for m in ICC_MODEL_ADDITIONS.get(ws.title, [])
                     if m not in icc_models]
            if extra:
                icc_models = icc_models + extra
                icc_raw = ", ".join(icc_models)
                for m in extra:
                    ADDED.append({"sheet": ws.title, "cell": ws.cell(br, 1).coordinate,
                                  "added": m, "now": icc_raw})

            icc_models_all = icc_models or icc_models_all

            label = str(ws.cell(br, 2).value or "").strip()
            refrigerant, qualifier = parse_label(label)
            status = FILL_STATUS.get(cell_fill(ss, br, 2), "standard")

            rows = []
            for i in range(DATA_ROWS):
                r = br + 3 + i
                raw = ws.cell(r, 2).value
                f, c = split_temp(raw)
                pts = []
                for col in COND_COLS:
                    ctx = {"sheet": ws.title, "refrigerant": refrigerant,
                           "suction": raw, "condensing": cond[COND_COLS.index(col)]["label"]}
                    btu, bad_b = num(ws, r, col, dict(ctx, unit="BTU/H"))
                    watt, bad_w = num(ws, r, col + 1, dict(ctx, unit="Watts"))
                    pt = {"btu": btu, "w": watt}
                    if bad_b or bad_w:
                        pt["bad"] = {k: v for k, v in (("btu", bad_b), ("w", bad_w)) if v}
                    fx = {}
                    for key, ccol in (("btu", col), ("w", col + 1)):
                        cd = ws.cell(r, ccol).coordinate
                        if (ws.title, cd) in CORRECTIONS:
                            fx[key] = CORRECTIONS[(ws.title, cd)][0]
                    if fx:
                        pt["fixed"] = fx
                    pts.append(pt)
                rows.append({"label": raw, "f": f, "c": c, "points": pts})

                for j, col in enumerate(COND_COLS):
                    _b = pts[j]["btu"]
                    _w = pts[j]["w"]
                    long_rows.append({
                        "sheet": ws.title,
                        "compressor_model": ws.title,
                        "icc_model": icc_raw,
                        "refrigerant": refrigerant,
                        "refrigerant_note": qualifier,
                        "status": status,
                        "suction_f": f,
                        "suction_c": c,
                        "condensing_f": cond[j]["f"],
                        "condensing_c": cond[j]["c"],
                        "capacity_btuh": "" if _b is None else _b,
                        "capacity_w": "" if _w is None else _w,
                        "not_rated": "" if _b is not None else "Y",
                    })

            blocks.append({
                "iccModel": icc_raw,
                "iccModels": icc_models,
                "label": label,
                "refrigerant": refrigerant,
                "qualifier": qualifier,
                "status": status,
                "rows": rows,
            })

        # application: LBP (freezer) families use MBIF / SUOF etc.
        fam = "".join(icc_models_all)
        app = "Low temp" if re.search(r"(MBIF|SUIF|SUOF)", fam) else "Medium temp"

        sheets.append({
            "name": ws.title,
            "compressorModel": ws.title,
            "iccModel": blocks[0]["iccModel"],
            "iccModels": blocks[0]["iccModels"],
            "application": app,
            "headers": {
                "modelCol": ws.cell(2, 1).value,
                "suctionCol": ws.cell(2, 2).value,
                "suctionUnits": ws.cell(3, 2).value,
                "btuLabel": ws.cell(3, 3).value,
                "wattLabel": ws.cell(3, 4).value,
            },
            "condensing": cond,
            "blocks": blocks,
        })

        # per-sheet wide CSV mirroring the Excel layout
        path = os.path.join(OUT, "csv", f"{ws.title}.csv")
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            for b in blocks:
                w.writerow([b["iccModel"], b["label"]])
                hdr = [ws.cell(2, 1).value, ws.cell(2, 2).value]
                for cd in cond:
                    hdr += [cd["label"], ""]
                w.writerow(hdr)
                sub = ["", ws.cell(3, 2).value]
                for _ in cond:
                    sub += ["BTU/H", "Watts"]
                w.writerow(sub)
                for i, row in enumerate(b["rows"]):
                    line = [ws.title if i == 0 else "", row["label"]]
                    for p in row["points"]:
                        line += ["-" if p["btu"] is None else p["btu"],
                                 "-" if p["w"] is None else p["w"]]
                    w.writerow(line)
                w.writerow([])

    data = {
        "source": os.path.basename(SRC),
        "status": "PROVISIONAL \u2014 under verification; not confirmed for publication",
        "title": "Condensing Units & Evaporators — Keeprite comparison",
        "units": {"capacity": "BTU/H", "power": "Watts"},
        "sheets": sheets,
        "issues": ISSUES,
        "corrections": FIXED,
        "modelAdditions": ADDED,
    }

    with open(os.path.join(OUT, "data.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1)

    # one flat long-format CSV covering everything
    with open(os.path.join(OUT, "csv", "_all-capacities-long.csv"), "w",
              newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(long_rows[0].keys()))
        w.writeheader()
        w.writerows(long_rows)

    print(f"sheets: {len(sheets)}  long rows: {len(long_rows)}")
    print(f"unresolved anomalies: {len(ISSUES)} -> {ISSUES}")
    print(f"ICC model additions: {len(ADDED)}")
    for a in sorted({(x["sheet"], x["added"]) for x in ADDED}):
        print(f"  {a[0]}  + {a[1]}")
    print(f"corrections applied: {len(FIXED)}")
    for f in FIXED:
        print(f"  {f['sheet']}!{f['cell']}  {f['raw']!r} -> {f['corrected']}")
    print(f"json bytes: {os.path.getsize(os.path.join(OUT, 'data.json')):,}")


if __name__ == "__main__":
    main()
