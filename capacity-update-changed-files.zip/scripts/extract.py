#!/usr/bin/env python3
"""
Extract the InvoTech comparison workbook into structured JSON + CSV.

Workbook shape (identical on every sheet):
  5 blocks starting at rows 1, 14, 27, 40, 53
  block row+0 : A = ICC model(s), B:P merged = refrigerant label
  block row+1 : A = 'Compressor Model', B = 'Sat. Suction Temp F', C..P = 7 condensing temps (2 cols each)
  block row+2 : B = 'F (C)', C..P = BTU/H | Watts pairs
  block row+3..+11 : 9 suction-temperature data rows
"""
import argparse
import csv
import glob
import json
import os
import re

import openpyxl

NOT_RATED = "-"          # source marker for "outside the rating envelope"

# Known transcription errors in the source workbook, corrected on extraction.
# Keyed by (sheet, cell) -> (corrected value, reason).
CORRECTIONS = {
    ("YF13E3G", "D9"): (
        3805,
        "Source cell held the letter 'a'. The R507 co-rated block on the same "
        "sheet gives 3805 W at this condition, and 12,983 BTU/H x 0.29307 = 3,805 W.",
    ),
}

# ICC model numbers that belong to a sheet but are not in the workbook's model
# column yet. Applied to every block on that sheet. Remove an entry once the
# workbook itself carries the number.
ICC_MODEL_ADDITIONS = {
    "NEU6215GK": ["MBIC500"],
    "YF13E3G": ["SUIF2000", "SUOF2000"],
    "YF20E3G": ["SUIF1000", "SUOF1000"],
    "YF29E3G": ["SUIF1500", "SUOF1500"],
}

# ---------------------------------------------------------------------------
# Field-application notes, per ICC unit. These are ICC's own notes about using
# a unit - conditions, limitations, disclaimers - not provenance for the data.
# They render under the unit header on the page and at the foot of the unit's
# sheet in the unit workbook. Keep `fold` for the long sections so the
# disclaimer stays visible without burying the capacity table; print always
# opens them.
# ---------------------------------------------------------------------------
# Conditions of use that are identical across every Secop R448A/R449A note.
# Held once so a wording change is made in one place. Each unit supplies the
# two lines that differ - the electrical-parts line and the nameplate line -
# because those depend on the compressor and on whether the release is 50 Hz.
def _secop_conditions(electrical, nameplate):
    return [
        "Medium-temp (MBP) duty only. Do not use on low-temp (LBP) duty \u2014 Secop "
        "prohibits R448A/R449A for LBP on its compressors.",
        "Expansion device: TXV with an R448A/R449A-rated element, or a capillary "
        "re-sized for the new refrigerant.",
        "Superheat set from the dew-point temperature (R448A/R449A glide is approx. "
        "7\u201310 \u00b0F); subcooling from bubble point.",
        "Charge in liquid phase only (zeotropic blend); re-optimise charge amount "
        "\u2014 typically lower than R404A.",
        "Discharge temperature runs higher than R404A: check discharge line temp at "
        "max condensing and keep within Secop's limit (confirm figure with Secop).",
        "Expect lower capacity and efficiency than R404A at the same conditions "
        "\u2014 size the unit with margin.",
        "HP/LP pressure switch and control settings taken from the R448A/R449A P-T chart.",
        "Oil: POE, same as R404A \u2014 no change needed.",
        "Filter drier and service components rated for POE and HFO blends.",
        electrical,
        nameplate,
        "At commissioning, record suction/discharge pressures, superheat, subcooling "
        "and discharge temperature.",
    ]


_SECOP_BULLETIN = ("Secop product bulletin DES.N.000.R1.02, Multi-Refrigerant Release of "
                   "Secop Compressor Types R448A and R449A, 02-2022.")

UNIT_NOTES = {
    "SUIC386": {
        "kicker": "R449A / R448A \u2014 field-application notes",
        "title": "Not manufacturer rated",
        "lead": "The SC10CL is not on Secop's R448A/R449A release list. The R449A and "
                "R448A figures on this sheet are reference only, not Secop-published ratings.",
        "sub": "Use with these refrigerants is at ICC's own engineering risk, outside the "
               "compressor's published envelope, and may affect the compressor warranty.",
        "fold": "Conditions for use, and path to a genuine rating",
        "sections": [
            {"heading": "Conditions for use", "items": _secop_conditions(
                electrical="Electrical parts (start relay, capacitor, protector): Secop kept "
                           "these unchanged on its released models; no change expected, but "
                           "not confirmed for SC10CL.",
                nameplate="Unit nameplate states refrigerant and charge; the compressor label "
                          "will not show R448A/R449A.")},
            {"heading": "Path to a genuine rating", "items": [
                "Written approval from Secop with an R448A/R449A operating envelope and "
                "capacity data for the SC10CL, or",
                "Switch to a released model: SC10MLX / SC12MLX (listed at 220\u2013240 V / "
                "50 Hz \u2014 confirm 60 Hz availability).",
            ]},
        ],
        "source": _SECOP_BULLETIN,
    },

    "SUIC530": {
        "kicker": "R448A / R449A \u2014 field-application notes",
        "title": "60 Hz figures derived, not Secop-published",
        "lead": "Secop lists the SC15MLX for R448A/R449A at 220\u2013240 V / 50 Hz only. The "
                "60 Hz R448A figures on this sheet are derived, and R449A is an R448A proxy "
                "\u2014 not Secop-published ratings.",
        "sub": "Use at 60 Hz is at ICC's own engineering risk, outside Secop's published "
               "data for this voltage/frequency, and may affect the compressor warranty.",
        "fold": "Conditions for use, and path to a genuine 60 Hz rating",
        "sections": [
            {"heading": "Conditions for use", "items": _secop_conditions(
                electrical="Electrical parts (start relay, capacitor, protector): Secop states "
                           "no change to starting equipment or accessories is needed for "
                           "R448A/R449A (50 Hz release); not confirmed for 60 Hz.",
                nameplate="Unit nameplate states refrigerant and charge; Secop will not add "
                          "R448A/R449A to the compressor label.")},
            {"heading": "Path to a genuine 60 Hz rating", "items": [
                "Written confirmation from Secop of the R448A/R449A operating limits and "
                "capacity data for the SC15MLX at 60 Hz, or",
                "Use the 50 Hz SC15MLX (104L2869, 220\u2013240 V) where the supply allows "
                "\u2014 it is on Secop's released list.",
            ]},
        ],
        "source": _SECOP_BULLETIN,
    },

    # InvoTech YM-series notes. They share too little wording with each other
    # (two bullets) or with the Secop notes above to be worth a shared list, so
    # each is held in full.
    "SUOC2000": {
        "kicker": "R449A / R448A \u2014 field-application notes",
        "title": "YM34E3G datasheet not yet confirmed",
        "lead": "InvoTech's YM-series literature covers R404A/R448A/R449A, but the R449A "
                "and R448A blocks on this sheet are not marked as InvoTech-published. "
                "Reference only until checked against the YM34E3G datasheet.",
        "sub": "Use with these refrigerants is at ICC's own engineering risk until InvoTech "
               "confirms the YM34E3G envelope and capacity in writing, and may affect the "
               "compressor warranty.",
        "fold": "Conditions for use, and path to a confirmed rating",
        "sections": [
            {"heading": "Conditions for use", "items": [
                "Medium-temp (MBP) duty. InvoTech's YM R448A/R449A datasheets are "
                "medium-temp; check the YM34E3G operating envelope before any low-temp use.",
                "Expansion device: TXV with an R448A/R449A-rated element, or a capillary "
                "re-sized for the new refrigerant.",
                "Superheat set from the dew-point temperature (zeotropic glide); subcooling "
                "from bubble point.",
                "Charge liquid only, through the liquid line \u2014 not through the suction "
                "or discharge line (InvoTech application note). Re-optimise charge amount.",
                "Oil: POE, same as R404A. Keep the oil-to-refrigerant weight ratio at 0.4 or "
                "higher (InvoTech charge limitation) \u2014 check on long line sets.",
                "Discharge temperature runs higher than R404A. The scroll has internal "
                "discharge-temperature management, but still check discharge line temp at "
                "max condensing.",
                "Expect lower capacity and efficiency than R404A at the same conditions "
                "\u2014 size the unit with margin.",
                "HP/LP pressure switch and control settings taken from the R448A/R449A P-T chart.",
                "Filter drier and service components rated for POE and HFO blends.",
                "Motor protection is internal (overload and high-pressure protection, "
                "internal pressure relief valve); no external component change is indicated "
                "in InvoTech's YM-series documents.",
                "Unit nameplate states refrigerant and charge.",
                "At commissioning, record suction/discharge pressures, superheat, subcooling "
                "and discharge temperature.",
            ]},
            {"heading": "Path to a confirmed rating", "items": [
                "Obtain the YM34E3G datasheet page for R448A/R449A from InvoTech and check "
                "it against the blocks on this sheet, or",
                "Ask InvoTech to confirm in writing the R448A/R449A operating envelope and "
                "capacity for the YM34E3G at 60 Hz.",
            ]},
        ],
        "source": "InvoTech YM/YSM series catalogue (engineering code E = R404A, R448A, "
                  "R449A); InvoTech YM49E3G-100 and YM182E7G-100 datasheets (R448A/R449A). "
                  "YM34E3G-specific datasheet not sighted.",
    },

    "SUOC3000": {
        "kicker": "R449A / R448A \u2014 field-application notes",
        "title": "InvoTech datasheet lists R448A/R449A; sheet figures to be reconciled",
        "lead": "InvoTech's YM49E3G-100 datasheet is issued for R448A/R449A (medium temp). "
                "The R449A and R448A blocks on this sheet are not labelled as "
                "InvoTech-published, and read about 80\u201388% of the datasheet "
                "performance table.",
        "sub": "Treat these blocks as reference only until reconciled with the datasheet. "
               "Use outside the datasheet's operating envelope is at ICC's own engineering "
               "risk and may affect the compressor warranty.",
        "fold": "Conditions for use, and path to a confirmed rating",
        "sections": [
            {"heading": "Conditions for use", "items": [
                "Medium-temp (MBP) duty only. Operate only inside the datasheet's operating "
                "envelope (InvoTech: compressor must not work outside it); keep suction "
                "superheat to avoid liquid flood-back.",
                "Rated point (datasheet): evaporating -6.7 \u00b0C / condensing 48.9 \u00b0C / "
                "11.1 K superheat / 0 K subcooling = 20,560 BTU/H (6,026 W), "
                "208-230 V / 1~ / 60 Hz.",
                "Expansion device: TXV with an R448A/R449A-rated element, or a capillary "
                "re-sized for the new refrigerant.",
                "Superheat set from the dew-point temperature (zeotropic glide); subcooling "
                "from bubble point.",
                "Charge liquid only. Do not charge through the suction or discharge line "
                "near the compressor \u2014 use the suction accumulator or receiver "
                "connection, far from the compressor (InvoTech).",
                "Do not vacuum the system with the compressor. If the full charge cannot go "
                "in first, charge at least 50% before starting, then add the rest while "
                "running (InvoTech).",
                "Oil: POE. Keep the oil-to-refrigerant weight ratio at 0.4 or higher "
                "(InvoTech charge limitation) \u2014 check on long line sets.",
                "Discharge temperature limit 125 \u00b0C, measured 120 mm from the discharge "
                "connection on an insulated line (InvoTech). Check at maximum condensing.",
                "Electrical parts per datasheet: start capacitor 160 \u00b5F, start relay "
                "HLR3800-4AI3D, run capacitor 60 \u00b5F / 450 V, internal overload "
                "protector. No change is indicated for R448A/R449A.",
                "Motor insulation class B (130 \u00b0C). Operating voltage 187\u2013253 V.",
                "HP/LP pressure switch and control settings taken from the R448A/R449A P-T "
                "chart. Max operating pressure: high side 3.2 MPa, low side 2.0 MPa.",
                "Unit nameplate states refrigerant and charge. At commissioning, record "
                "pressures, superheat, subcooling and discharge temperature.",
            ]},
            {"heading": "Path to a confirmed rating", "items": [
                "Replace or check the R448A/R449A blocks against the YM49E3G-100 datasheet "
                "performance table (or its polynomial coefficients), or",
                "Ask InvoTech to confirm the basis (superheat, subcooling, return gas) of "
                "the figures on this sheet.",
            ]},
        ],
        "source": "InvoTech YM49E3G-100 technical datasheet (R448A/R449A, medium temp). "
                  "Sheet-vs-datasheet comparison is approximate, interpolated from the "
                  "datasheet table at 9 grid points (79\u201388%).",
    },

}

# Free-text notes pinned to a sheet, shown in the notes panel above its tables.
# Use these to record anything that needs revisiting - a pairing that looks odd,
# a figure taken on trust, a question for the manufacturer.
SHEET_NOTES = {
    "YF13E3G": [
        "SUIF2000 and SUOF2000 are recorded from the ERP as-is. The numbering "
        "does not follow the rest of the set: every other sheet shares one "
        "suffix across its ICC models (MBIF1000 with SUIF1000 and SUOF1000), "
        "and the number otherwise tracks capacity, but here 2000 sits with "
        "MBIF600 on the second-smallest freezer compressor - below SUIF1000 "
        "and SUIF1500, which are on larger units. Flagged for the InvoTech "
        "cross-check rather than corrected.",
    ],
}

# ---------------------------------------------------------------------------
# Which refrigerant(s) each ICC unit is offered with. Supplied by John from the
# ERP, 2026-08-28. PENDING CONFIRMATION: 23 of the 39 unit/refrigerant pairs
# point at blocks the workbook flags as not released, not suitable, or
# estimated - see verification-log.md. The flags are shown as-is on the page
# rather than being resolved here.
# ---------------------------------------------------------------------------
SELECTIONS = {
    "SUIC386": ["R448A"], "SUIC500": ["R448A"], "SUIC530": ["R448A"],
    "SUIC700": ["R448A"], "SUIC1000": ["R448A"], "SUIC1500": ["R448A"],
    "SUOC500": ["R448A"], "SUOC700": ["R448A"], "SUOC1000": ["R448A"],
    "SUOC1500": ["R448A"], "SUOC2000": ["R448A"], "SUOC3000": ["R448A"],
    "SUOC4000": ["R448A"],
    "MBIC350": ["R448A", "R404A", "R449A"], "MBIC500": ["R448A", "R404A", "R449A"],
    "MBIC750": ["R448A", "R404A", "R449A"], "MBIC1000": ["R448A", "R404A", "R449A"],
    "MBIC1500": ["R448A", "R404A", "R449A"],
    "SUIF1000": ["R448A"], "SUIF1500": ["R448A"], "SUIF2000": ["R448A"],
    "SUOF1000": ["R448A"], "SUOF1500": ["R448A"], "SUOF2000": ["R448A"],
    "SUOF3000": ["R448A"], "SUOF4000": ["R448A"],
    "MBIF450": ["R448A", "R404A", "R449A"], "MBIF600": ["R448A", "R404A", "R449A"],
    "MBIF1000": ["R448A", "R404A", "R449A"], "MBIF1500": ["R448A", "R404A", "R449A"],
}

# Unit families, in the order they are listed on the page.
FAMILY = [
    ("SUIC", "SUIC \u00b7 indoor cooler"),
    ("SUOC", "SUOC \u00b7 outdoor cooler"),
    ("MBIC", "MBIC \u00b7 cooler, multi-refrigerant"),
    ("SUIF", "SUIF \u00b7 indoor freezer"),
    ("SUOF", "SUOF \u00b7 outdoor freezer"),
    ("MBIF", "MBIF \u00b7 freezer, multi-refrigerant"),
]

ISSUES = []              # cells that are neither a number nor "-"
FIXED = []               # corrections actually applied
ADDED = []               # ICC model numbers added from ICC_MODEL_ADDITIONS
TEXT_NUMBERS = []        # cells holding a number as text; coerced, not flagged

DEFAULT_GLOB = "/mnt/user-data/uploads/*.xlsx"
BLOCK_ROWS = [1, 14, 27, 40, 53]
DATA_ROWS = 9
COND_COLS = list(range(3, 17, 2))  # C, E, G, I, K, M, O

# Excel fill -> semantic status (preserved from the source workbook)
FILL_STATUS = {
    "FFD9E1F2": "standard",  # blue  - rated / released
    "FFFCE4D6": "caution",   # peach - not released / reference only
    "FFFFF2CC": "note",      # yellow- released with a qualifier
}


def split_temp(text):
    """'80 (26.7)' -> (80.0, 26.7). '30 (-1.1)' -> (30.0, -1.1)."""
    m = re.match(r"^\s*(-?[\d.]+)\s*\(\s*(-?[\d.]+)\s*\)\s*$", str(text))
    if not m:
        return None, None
    return float(m.group(1)), float(m.group(2))


def parse_label(label):
    """'R452A (released)' -> ('R452A', 'released')."""
    m = re.match(r"^\s*([^\s(]+)\s*(?:\((.*)\))?\s*$", str(label))
    if not m:
        return str(label), ""
    return m.group(1), (m.group(2) or "").strip()


def as_number(text):
    """Parse a number held as text - the green-triangle cells Excel warns about.
    Handles thousands separators, stray spaces and a unicode minus. Returns None
    if the text is not a number."""
    t = (str(text).strip()
         .replace(",", "").replace("\u00a0", "").replace(" ", "")
         .replace("\u2212", "-"))
    if not t:
        return None
    try:
        f = float(t)
    except ValueError:
        return None
    return int(f) if f.is_integer() else f


def num(ws, row, col, ctx):
    """Return (value, flag). value is a number or None ('-' = not rated).
    flag is None, or the raw text of a cell that could not be resolved."""
    coord = ws.cell(row, col).coordinate
    v = ws.cell(row, col).value

    fix = CORRECTIONS.get((ws.title, coord))
    if fix is not None:
        value, reason = fix
        FIXED.append(dict(ctx, cell=coord, raw=str(v).strip(),
                          corrected=value, reason=reason))
        return value, None

    if isinstance(v, (int, float)):
        return v, None

    t = str(v).strip()
    if t == NOT_RATED:
        return None, None

    # numbers stored as text read as numbers, silently
    n = as_number(t)
    if n is not None:
        TEXT_NUMBERS.append({"sheet": ws.title, "cell": coord})
        return n, None

    ISSUES.append(dict(ctx, cell=coord, raw=t))
    return None, t


def cell_fill(ws, row, col):
    c = ws.cell(row, col)
    rgb = None
    if c.fill is not None and c.fill.fgColor is not None:
        rgb = c.fill.fgColor.rgb
    return rgb if isinstance(rgb, str) else None


def load_extra_sheets(directory, cond_default):
    """Sheets not yet in the workbook, held as JSON in extra-sheets/.

    Each file carries its own provenance and notes, and is built into the same
    shape as an extracted sheet so nothing downstream needs to know the
    difference. Delete the file once the tab exists in the workbook and
    re-extract - the pipeline is the source of truth, this is a staging area.
    """
    out = []
    if not os.path.isdir(directory):
        return out

    for path in sorted(glob.glob(os.path.join(directory, "*.json"))):
        with open(path, encoding="utf-8") as fh:
            doc = json.load(fh)

        cond = []
        for lab in doc.get("condensing") or [c["label"] for c in cond_default]:
            f, c = split_temp(lab)
            cond.append({"label": lab, "f": f, "c": c})

        icc_raw = doc["iccModel"]
        icc_models = [m.strip() for m in icc_raw.split(",") if m.strip()]
        extra = [m for m in ICC_MODEL_ADDITIONS.get(doc["name"], []) if m not in icc_models]
        if extra:
            icc_models += extra
            icc_raw = ", ".join(icc_models)

        blocks = []
        for b in doc["blocks"]:
            refrigerant, qualifier = parse_label(b["label"])
            rows = []
            for lab, flat in zip(doc["suction"], b["rows"]):
                f, c = split_temp(lab)
                pts = []
                for i in range(0, len(flat), 2):
                    pt, bad = {}, {}
                    for key, raw in (("btu", flat[i]), ("w", flat[i + 1])):
                        if isinstance(raw, (int, float)):
                            pt[key] = raw
                            continue
                        t = str(raw).strip()
                        if t == NOT_RATED:
                            pt[key] = None
                            continue
                        n = as_number(t)
                        if n is not None:
                            pt[key] = n
                            continue
                        # unreadable in the source, e.g. Excel's ##### column overflow
                        pt[key] = None
                        bad[key] = t
                        ISSUES.append({"sheet": doc["name"], "cell": "",
                                       "refrigerant": refrigerant, "suction": lab,
                                       "condensing": cond[i // 2]["label"],
                                       "unit": "BTU/H" if key == "btu" else "Watts",
                                       "raw": t})
                    if bad:
                        pt["bad"] = bad
                    pts.append(pt)
                rows.append({"label": lab, "f": f, "c": c, "points": pts})
            blocks.append({
                "iccModel": icc_raw, "iccModels": icc_models,
                "highlight": doc.get("highlight", False),
                "label": b["label"], "refrigerant": refrigerant,
                "qualifier": qualifier, "status": b.get("status", "standard"),
                "rows": rows,
            })

        fam = "".join(icc_models)
        out.append({
            "name": doc["name"],
            "compressorModel": doc["name"],
            "iccModel": icc_raw,
            "iccModels": icc_models,
            "application": "Low temp" if re.search(r"(MBIF|SUIF|SUOF)", fam) else "Medium temp",
            "sourceType": doc.get("sourceType", "external"),
            "sourceNote": doc.get("sourceNote", ""),
            "notes": doc.get("notes", []) + SHEET_NOTES.get(doc["name"], []),
            "headers": {"modelCol": "Compressor Model", "suctionCol": "Sat. Suction Temp \u00b0F",
                        "suctionUnits": "\u00b0F (\u00b0C)", "btuLabel": "BTU/H", "wattLabel": "Watts"},
            "condensing": cond,
            "blocks": blocks,
        })
    return out


def family_of(model):
    for prefix, label in FAMILY:
        if model.startswith(prefix):
            return label
    return "Other"


def build_units(sheets):
    """One entry per ICC unit, shaped like a sheet so the page and the workbook
    generator can render either without a second code path.

    A compressor can serve several units with different selections - NEU6215GK
    carries SUIC500 and SUOC500 (R448A only) alongside MBIC500 (three
    refrigerants) - which is why the unit, not the compressor, is the entity
    here. `allBlocks` keeps the full set so the delta baseline still resolves
    when R404A is not among the selected refrigerants.
    """
    where = {}
    for sheet in sheets:
        for m in sheet["iccModels"]:
            where[m] = sheet

    order = [label for _, label in FAMILY]
    units = []
    for model, refs in SELECTIONS.items():
        sheet = where.get(model)
        if sheet is None:
            print(f"  WARNING: {model} is in SELECTIONS but no sheet lists it")
            continue
        blocks, missing = [], []
        for r in refs:
            hit = [b for b in sheet["blocks"] if b["refrigerant"] == r]
            if hit:
                blocks.append(dict(hit[0], iccModel=model, iccModels=[model]))
            else:
                missing.append(r)
        if missing:
            print(f"  WARNING: {model} selects {missing} which {sheet['name']} does not carry")
        units.append({
            "name": model,
            "compressorModel": sheet["compressorModel"],
            "iccModel": model,
            "iccModels": [model],
            "application": sheet["application"],
            "family": family_of(model),
            "selected": refs,
            "flagged": [b["refrigerant"] for b in blocks if b["status"] != "standard"],
            "notes": sheet.get("notes", []),
            "note": UNIT_NOTES.get(model),
            "headers": sheet["headers"],
            "condensing": sheet["condensing"],
            "blocks": blocks,
            "allBlocks": sheet["blocks"],
        })

    units.sort(key=lambda u: (order.index(u["family"]) if u["family"] in order else 9,
                              int("".join(c for c in u["name"] if c.isdigit()) or 0)))
    return units


def find_source():
    hits = sorted(glob.glob(DEFAULT_GLOB))
    if not hits:
        raise SystemExit(
            "No .xlsx found in /mnt/user-data/uploads. Pass the workbook path with --source.")
    if len(hits) > 1:
        raise SystemExit("Several workbooks found; name one with --source:\n  " +
                         "\n  ".join(hits))
    return hits[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source", help="path to the capacity workbook (.xlsx)")
    ap.add_argument("--out", default="build", help="output directory (default: build)")
    args = ap.parse_args()

    SRC = args.source or find_source()
    OUT = args.out
    print(f"source: {SRC}")

    os.makedirs(OUT, exist_ok=True)
    os.makedirs(os.path.join(OUT, "csv"), exist_ok=True)

    wb_v = openpyxl.load_workbook(SRC, data_only=True)   # values
    wb_s = openpyxl.load_workbook(SRC)                    # styles

    sheets = []
    long_rows = []

    for ws in wb_v.worksheets:
        ss = wb_s[ws.title]

        # condensing temperatures come from the first block header; verified identical
        # across every block and every sheet.
        cond = []
        for col in COND_COLS:
            raw = ws.cell(2, col).value
            f, c = split_temp(raw)
            cond.append({"label": raw, "f": f, "c": c})

        blocks = []
        icc_models_all = []

        for br in BLOCK_ROWS:
            icc_raw = str(ws.cell(br, 1).value or "").strip()
            icc_models = [m.strip() for m in icc_raw.split(",") if m.strip()]

            extra = [m for m in ICC_MODEL_ADDITIONS.get(ws.title, [])
                     if m not in icc_models]
            if extra:
                icc_models = icc_models + extra
                icc_raw = ", ".join(icc_models)
                for m in extra:
                    ADDED.append({"sheet": ws.title, "cell": ws.cell(br, 1).coordinate,
                                  "added": m, "now": icc_raw})

            icc_models_all = icc_models or icc_models_all

            # John highlights the model cell yellow to mark a sheet he is
            # still working through; preserved so a rebuilt workbook keeps it.
            highlight = cell_fill(ss, br, 1) == "FFFFFF00"

            label = str(ws.cell(br, 2).value or "").strip()
            refrigerant, qualifier = parse_label(label)
            status = FILL_STATUS.get(cell_fill(ss, br, 2), "standard")

            rows = []
            for i in range(DATA_ROWS):
                r = br + 3 + i
                raw = ws.cell(r, 2).value
                f, c = split_temp(raw)
                pts = []
                for col in COND_COLS:
                    ctx = {"sheet": ws.title, "refrigerant": refrigerant,
                           "suction": raw, "condensing": cond[COND_COLS.index(col)]["label"]}
                    btu, bad_b = num(ws, r, col, dict(ctx, unit="BTU/H"))
                    watt, bad_w = num(ws, r, col + 1, dict(ctx, unit="Watts"))
                    pt = {"btu": btu, "w": watt}
                    if bad_b or bad_w:
                        pt["bad"] = {k: v for k, v in (("btu", bad_b), ("w", bad_w)) if v}
                    fx = {}
                    for key, ccol in (("btu", col), ("w", col + 1)):
                        cd = ws.cell(r, ccol).coordinate
                        if (ws.title, cd) in CORRECTIONS:
                            fx[key] = CORRECTIONS[(ws.title, cd)][0]
                    if fx:
                        pt["fixed"] = fx
                    pts.append(pt)
                rows.append({"label": raw, "f": f, "c": c, "points": pts})

                for j, col in enumerate(COND_COLS):
                    _b = pts[j]["btu"]
                    _w = pts[j]["w"]
                    long_rows.append({
                        "sheet": ws.title,
                        "compressor_model": ws.title,
                        "icc_model": icc_raw,
                        "refrigerant": refrigerant,
                        "refrigerant_note": qualifier,
                        "status": status,
                        "suction_f": f,
                        "suction_c": c,
                        "condensing_f": cond[j]["f"],
                        "condensing_c": cond[j]["c"],
                        "capacity_btuh": "" if _b is None else _b,
                        "capacity_w": "" if _w is None else _w,
                        "not_rated": "" if _b is not None else "Y",
                    })

            blocks.append({
                "iccModel": icc_raw,
                "iccModels": icc_models,
                "highlight": highlight,
                "label": label,
                "refrigerant": refrigerant,
                "qualifier": qualifier,
                "status": status,
                "rows": rows,
            })

        # application: LBP (freezer) families use MBIF / SUOF etc.
        fam = "".join(icc_models_all)
        app = "Low temp" if re.search(r"(MBIF|SUIF|SUOF)", fam) else "Medium temp"

        sheets.append({
            "name": ws.title,
            "notes": SHEET_NOTES.get(ws.title, []),
            "compressorModel": ws.title,
            "iccModel": blocks[0]["iccModel"],
            "iccModels": blocks[0]["iccModels"],
            "application": app,
            "headers": {
                "modelCol": ws.cell(2, 1).value,
                "suctionCol": ws.cell(2, 2).value,
                "suctionUnits": ws.cell(3, 2).value,
                "btuLabel": ws.cell(3, 3).value,
                "wattLabel": ws.cell(3, 4).value,
            },
            "condensing": cond,
            "blocks": blocks,
        })

        # per-sheet wide CSV mirroring the Excel layout
        path = os.path.join(OUT, "csv", f"{ws.title}.csv")
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            for b in blocks:
                w.writerow([b["iccModel"], b["label"]])
                hdr = [ws.cell(2, 1).value, ws.cell(2, 2).value]
                for cd in cond:
                    hdr += [cd["label"], ""]
                w.writerow(hdr)
                sub = ["", ws.cell(3, 2).value]
                for _ in cond:
                    sub += ["BTU/H", "Watts"]
                w.writerow(sub)
                for i, row in enumerate(b["rows"]):
                    line = [ws.title if i == 0 else "", row["label"]]
                    for p in row["points"]:
                        line += ["-" if p["btu"] is None else p["btu"],
                                 "-" if p["w"] is None else p["w"]]
                    w.writerow(line)
                w.writerow([])

    extra_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "extra-sheets")
    for sh in load_extra_sheets(extra_dir, sheets[0]["condensing"]):
        sheets.append(sh)
        print(f"extra sheet: {sh['name']} ({sh['iccModel']}) from {sh['sourceType']}")
        path = os.path.join(OUT, "csv", f"{sh['name']}.csv")
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            for b in sh["blocks"]:
                w.writerow([b["iccModel"], b["label"]])
                hdr = [sh["headers"]["modelCol"], sh["headers"]["suctionCol"]]
                for cd in sh["condensing"]:
                    hdr += [cd["label"], ""]
                w.writerow(hdr)
                sub = ["", sh["headers"]["suctionUnits"]]
                for _ in sh["condensing"]:
                    sub += ["BTU/H", "Watts"]
                w.writerow(sub)
                for i, row in enumerate(b["rows"]):
                    line = [sh["name"] if i == 0 else "", row["label"]]
                    for p in row["points"]:
                        line += [p["btu"], p["w"]]
                    w.writerow(line)
                w.writerow([])
                for ri, row in enumerate(b["rows"]):
                    for j, cd in enumerate(sh["condensing"]):
                        long_rows.append({
                            "sheet": sh["name"], "compressor_model": sh["name"],
                            "icc_model": b["iccModel"], "refrigerant": b["refrigerant"],
                            "refrigerant_note": b["qualifier"], "status": b["status"],
                            "suction_f": row["f"], "suction_c": row["c"],
                            "condensing_f": cd["f"], "condensing_c": cd["c"],
                            "capacity_btuh": row["points"][j]["btu"],
                            "capacity_w": row["points"][j]["w"], "not_rated": "",
                        })

    data = {
        "source": os.path.basename(SRC),
        "status": "PROVISIONAL \u2014 under verification; not confirmed for publication",
        "title": "Condensing Units & Evaporators — capacity reference",
        "units": {"capacity": "BTU/H", "power": "Watts"},
        "sheets": sheets,
        "issues": ISSUES,
        "corrections": FIXED,
        "modelAdditions": ADDED,
        "units": build_units(sheets),
        "familyOrder": [label for _, label in FAMILY],
    }

    with open(os.path.join(OUT, "data.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1)

    # one flat long-format CSV covering everything
    with open(os.path.join(OUT, "csv", "_all-capacities-long.csv"), "w",
              newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(long_rows[0].keys()))
        w.writeheader()
        w.writerows(long_rows)

    print(f"sheets: {len(sheets)}  long rows: {len(long_rows)}")
    print(f"units: {len(data['units'])}  "
          f"({sum(1 for u in data['units'] if u['flagged'])} with a flagged selection, "
          f"{sum(1 for u in data['units'] if u.get('note'))} with a field note)")
    orphan = [m for m in UNIT_NOTES if m not in {u["name"] for u in data["units"]}]
    if orphan:
        print(f"  WARNING: UNIT_NOTES has entries for unknown units: {orphan}")
    print(f"unresolved anomalies: {len(ISSUES)} -> {ISSUES}")
    if TEXT_NUMBERS:
        print(f"numbers stored as text (coerced silently): {len(TEXT_NUMBERS)}")
    print(f"ICC model additions: {len(ADDED)}")
    for a in sorted({(x["sheet"], x["added"]) for x in ADDED}):
        print(f"  {a[0]}  + {a[1]}")
    print(f"corrections applied: {len(FIXED)}")
    for f in FIXED:
        print(f"  {f['sheet']}!{f['cell']}  {f['raw']!r} -> {f['corrected']}")
    print(f"json bytes: {os.path.getsize(os.path.join(OUT, 'data.json')):,}")


if __name__ == "__main__":
    main()
