#!/usr/bin/env python3
"""
Rebuild the capacity workbook from data.json, in the original file's format.

One sheet per compressor model, five refrigerant blocks per sheet at rows
1, 14, 27, 40 and 53, each block being a header row, two column-header rows and
nine suction-temperature rows. Fonts, fills, borders, column widths, merges and
number formats match the source workbook cell for cell.

    python3 scripts/build_workbook.py --data data.json --out Condensing_Units.xlsx

Corrections, added ICC model numbers and pinned notes are attached as cell
comments so the workbook carries its own provenance without changing layout.
"""
import argparse
import json
import os

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ---- format constants, taken from the source workbook -----------------------
FONT = "Aptos Narrow"
SIZE = 11
HEADER_FILL = "FFD9E1F2"          # blue   - rated / released
STATUS_FILL = {
    "standard": "FFD9E1F2",
    "caution":  "FFFCE4D6",       # peach  - not released / reference only
    "note":     "FFFFF2CC",       # yellow - released with a qualifier
}
STATUS_FONT = {
    "standard": "FF000000",
    "caution":  "FFC00000",       # the refrigerant label only; the model cell stays black
    "note":     "FF000000",
}
NOTE_ZEBRA = "FFEAF1F3"           # the page's alternating note-row tint
HIGHLIGHT = "FFFFFF00"            # yellow model cell - John's "still working on this" marker
# Column widths are set wide enough for the widest value in the whole dataset.
# The source workbook used narrower, per-sheet widths, which is what produced
# the ##### overflow on the SUOF4000 tab - a number too wide for its column is
# unreadable in the file and in any screenshot of it.
COL_WIDTHS = {
    "A": 31.0,   # widest model list is "SUIC1000, SUOC1000, MBIC1000" (28 chars)
    "B": 20.0,   # suction labels; the refrigerant label spans B:P so needs no room here
}
COL_WIDTHS.update({get_column_letter(c): 10.0 for c in range(3, 17)})
BLOCK_ROWS = [1, 14, 27, 40, 53]   # a block occupies 12 rows plus a spacer
NOT_RATED = "-"

THIN = Side(style="thin")
ALL   = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
TB    = Border(top=THIN, bottom=THIN)                 # merged-range interior
TBR   = Border(right=THIN, top=THIN, bottom=THIN)     # merged-range right edge


def head(cell, fill, color="FF000000", align="center"):
    cell.font = Font(name=FONT, size=SIZE, bold=True, color=color)
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.alignment = Alignment(horizontal=align)
    cell.border = ALL


def body(cell, numfmt="General"):
    cell.font = Font(name=FONT, size=SIZE)
    cell.alignment = Alignment(horizontal="center")
    cell.border = ALL
    cell.number_format = numfmt


def spanned(cell, last):
    """Interior of a merged range: no fill of its own, edge borders only."""
    cell.font = Font(name=FONT, size=SIZE)
    cell.border = TBR if last else TB


def caps(text):
    """Upper-case a label but keep unit symbols in their proper case."""
    return text.upper().replace(" HZ", " Hz").replace("HZ ", "Hz ")


def write_note(ws, sheet, start_row):
    """Field-application note at the foot of a unit sheet, below the blocks.

    Plain rows rather than a cell comment: the note is long, it has to print,
    and a comment prints nowhere. Kept below the last block so the fixed block
    geometry above it is untouched.
    """
    note = sheet.get("note")
    if not note:
        return

    r = start_row + 1
    last = 2 + len(sheet["condensing"]) * 2

    def line(text, *, bold=False, italic=False, size=SIZE, indent=False, fill=None):
        nonlocal r
        c = ws.cell(r, 1, text)
        c.font = Font(name=FONT, size=size, bold=bold, italic=italic)
        c.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True,
                                indent=2 if indent else 0)
        if fill:
            c.fill = PatternFill("solid", fgColor=fill)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=last)
        ws.row_dimensions[r].height = None
        r += 1

    line(caps(note.get("kicker", "Field-application notes")), bold=True, size=9)
    if note.get("title"):
        line(note["title"], bold=True, size=12)
    if note.get("lead"):
        line(note["lead"], bold=True)
    if note.get("sub"):
        line(note["sub"])
    r += 1

    for sec in note.get("sections", []):
        if sec.get("heading"):
            line(caps(sec["heading"]), bold=True, size=9)
        for i, item in enumerate(sec["items"]):
            line("\u2022  " + item, indent=True,
                 fill=NOTE_ZEBRA if i % 2 == 0 else None)
        r += 1

    if note.get("source"):
        line("Source: " + note["source"], italic=True, size=9)


def write_sheet(ws, sheet, meta):
    for col, width in COL_WIDTHS.items():
        ws.column_dimensions[col].width = width

    # the blocks are 16 columns wide; portrait at default scale splits them
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True

    h = sheet["headers"]
    ncond = len(sheet["condensing"])
    last_col = 2 + ncond * 2

    last_block_row = BLOCK_ROWS[len(sheet["blocks"]) - 1] + 11

    for bi, (top, block) in enumerate(zip(BLOCK_ROWS, sheet["blocks"])):
        fill = STATUS_FILL.get(block["status"], HEADER_FILL)
        color = STATUS_FONT.get(block["status"], "FF000000")

        # merge first: merging replaces interior cells and discards their styles
        ws.merge_cells(start_row=top, start_column=2, end_row=top, end_column=last_col)
        for j in range(ncond):
            c = 3 + j * 2
            ws.merge_cells(start_row=top + 1, start_column=c,
                           end_row=top + 1, end_column=c + 1)

        # --- block header row ---
        ws.cell(top, 1).value = block["iccModel"]
        head(ws.cell(top, 1),
             HIGHLIGHT if block.get("highlight") else fill,
             "FF000000", align="left")
        ws.cell(top, 2).value = block["label"]
        head(ws.cell(top, 2), fill, color)
        for c in range(3, last_col + 1):
            spanned(ws.cell(top, c), c == last_col)

        # --- condensing temperature row ---
        ws.cell(top + 1, 1).value = h["modelCol"]
        head(ws.cell(top + 1, 1), HEADER_FILL)
        ws.cell(top + 1, 2).value = h["suctionCol"]
        head(ws.cell(top + 1, 2), HEADER_FILL)
        for j, cond in enumerate(sheet["condensing"]):
            c = 3 + j * 2
            ws.cell(top + 1, c).value = cond["label"]
            head(ws.cell(top + 1, c), HEADER_FILL)
            spanned(ws.cell(top + 1, c + 1), True)

        # --- unit row ---
        head(ws.cell(top + 2, 1), HEADER_FILL)
        ws.cell(top + 2, 2).value = h["suctionUnits"]
        head(ws.cell(top + 2, 2), HEADER_FILL)
        for j in range(ncond):
            c = 3 + j * 2
            ws.cell(top + 2, c).value = h["btuLabel"]
            head(ws.cell(top + 2, c), HEADER_FILL)
            ws.cell(top + 2, c + 1).value = h["wattLabel"]
            head(ws.cell(top + 2, c + 1), HEADER_FILL)

        # --- data rows ---
        for ri, row in enumerate(block["rows"]):
            r = top + 3 + ri
            if ri == 0:
                ws.cell(r, 1).value = sheet["compressorModel"]
            body(ws.cell(r, 1))
            ws.cell(r, 2).value = row["label"]
            body(ws.cell(r, 2))
            for j, pt in enumerate(row["points"]):
                c = 3 + j * 2
                for k, key in enumerate(("btu", "w")):
                    v = pt.get(key)
                    ws.cell(r, c + k).value = NOT_RATED if v is None else v
                    body(ws.cell(r, c + k), numfmt="#,##0")

        # --- provenance as cell comments, so layout is untouched ---
        notes = []
        if bi == 0 and meta.get("selected"):
            notes.append("Offered with: " + ", ".join(meta["selected"]) +
                         ". Selection pending confirmation; refrigerant blocks "
                         "keep the source workbook's own release wording.")
        if bi == 0:
            notes += [f"{m} added to the model column outside the workbook."
                      for m in meta["additions"]]
            notes += sheet.get("notes", [])
        for f in meta["corrections"]:
            if f["refrigerant"] == block["refrigerant"]:
                notes.append(
                    f"Corrected: {f['unit']} at suction {f['suction']}, condensing "
                    f"{f['condensing']} held {f['raw']!r}; set to {f['corrected']:,}. "
                    f"{f['reason']}")
        if notes:
            cm = Comment("\n\n".join(notes), "compressor-capacity")
            cm.width, cm.height = 460, 40 + 34 * len(notes)
            ws.cell(top, 2).comment = cm

    write_note(ws, sheet, last_block_row)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", default="data.json")
    ap.add_argument("--out", default="Condensing_Units_and_Evaps.xlsx")
    ap.add_argument("--units", action="store_true",
                    help="one sheet per ICC unit with only its selected "
                         "refrigerants, instead of one sheet per compressor")
    args = ap.parse_args()

    with open(args.data, encoding="utf-8") as fh:
        data = json.load(fh)

    entities = data["units"] if args.units else data["sheets"]

    wb = Workbook()
    wb.remove(wb.active)
    # Default font for cells never written to, including the interiors of merged
    # ranges - openpyxl discards styles set on a MergedCell, so the only way to
    # reach them is the workbook default (index 0 of the font table).
    wb._fonts[0] = Font(name=FONT, size=SIZE)

    for sheet in entities:
        meta = {
            "additions": sorted({a["added"] for a in data.get("modelAdditions", [])
                                 if a["sheet"] == sheet["name"]}),
            "corrections": [c for c in data.get("corrections", [])
                            if c["sheet"] == sheet["compressorModel"]],
            "selected": sheet.get("selected"),
        }
        ws = wb.create_sheet(sheet["name"])
        write_sheet(ws, sheet, meta)

    wb.save(args.out)
    print(f"wrote {args.out}  ({os.path.getsize(args.out):,} bytes)")
    print(f"sheets: {len(entities)} ({'units' if args.units else 'compressors'})")


if __name__ == "__main__":
    main()
